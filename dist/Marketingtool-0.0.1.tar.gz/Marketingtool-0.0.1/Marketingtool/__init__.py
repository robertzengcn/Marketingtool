# -*- coding: utf-8 -*-


__author__ = 'Robert Zeng'
__updated__ = '18.08.2018'  # day.month.year

import logging

"""
All objects imported here are exposed as the public API of GoogleScraper
"""




logging.getLogger(__name__)
